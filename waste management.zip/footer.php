  <!--footer-->
  <footer class="buttom-footer py-lg-5 py-md-4 py-sm-3 py-3">
     <div class="container-fluid py-3">

        <div class="row">
           <div class="col-lg-7 col-md-7">
              <div class="headder-logo-icon text-center">
                 <h2><a href="index.html">Re-Cycly</a></h2>
              </div>
              <div class="footer-bottom py-lg-4 py-md-3 py-2 text-center">
                 <p>©2023 Re-Cycly.</p>
              </div>
           </div>
           <div class="col-lg-5 col-md-5">
              <div class="buttom-nav py-2">
                 <nav class="border-line">
                    <ul class="nav justify-content-center">
                       <li class="nav-item active">
                          <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
                       </li>
                       <li class="nav-item">
                          <a href="about.html" class="nav-link ">About</a>
                       </li>
                       <li class="nav-item">
                          <a href="service.html" class="nav-link">Services</a>
                       </li>
                       <li class="nav-item">
                          <a href="contact.html" class="nav-link">Contact</a>
                       </li>
                    </ul>
                 </nav>
              </div>
              <div class="icons text-center">
                 <ul>
                    <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                    <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                    <li><a href="#"><span class="fa fa-rss"></span></a></li>
                 </ul>
              </div>
           </div>
        </div>
     </div>
  </footer>
  <!--//footer-->

  </body>

  </html>