/*
SQLyog Ultimate v11.33 (64 bit)
MySQL - 10.4.11-MariaDB : Database - recycly
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`recycly` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `recycly`;

/*Table structure for table `agent_reg` */

DROP TABLE IF EXISTS `agent_reg`;

CREATE TABLE `agent_reg` (
  `ag_id` int(20) NOT NULL AUTO_INCREMENT,
  `ag_name` varchar(100) NOT NULL,
  `ag_age` varchar(100) NOT NULL,
  `ag_phone` varchar(100) NOT NULL,
  `ag_address` varchar(100) NOT NULL,
  `ag_email` varchar(100) NOT NULL,
  `ag_doj` varchar(100) NOT NULL,
  PRIMARY KEY (`ag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `agent_reg` */

insert  into `agent_reg`(`ag_id`,`ag_name`,`ag_age`,`ag_phone`,`ag_address`,`ag_email`,`ag_doj`) values (1,'Prakash','23','7876789098','Kaloor','prakash@gmail.com','2021-09-30'),(2,'Prashob','33','9086678897','Thrippunnithura, Ernakulam','prashob@gmail.com','06-12-2021'),(3,'Rugmini','22','9876543210','kaloor near stadium','rugmini@gmail.com','06-12-2021'),(4,'ASW','24','9999999999','ASW\r\nAdrs','asw@mail.com','14-06-2023'),(5,'ch','26','8888888888','ch\r\naDRS','ch@mail.com','2023-06-14 13:53:18'),(6,'Jeena','26','9595959595','Je\r\nAdr','je@mail.com','2023-06-15 17:02:27');

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `c_id` int(20) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `category` */

insert  into `category`(`c_id`,`category`) values (1,'Computer'),(2,'laptop'),(4,'Mobile');

/*Table structure for table `item` */

DROP TABLE IF EXISTS `item`;

CREATE TABLE `item` (
  `it_id` int(20) NOT NULL AUTO_INCREMENT,
  `cat_id` varchar(100) NOT NULL,
  `u_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `no_item` varchar(100) NOT NULL,
  `about` varchar(100) NOT NULL,
  `image` longblob NOT NULL,
  `status` varchar(100) DEFAULT 'PENDING',
  PRIMARY KEY (`it_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

/*Data for the table `item` */

insert  into `item`(`it_id`,`cat_id`,`u_id`,`name`,`no_item`,`about`,`image`,`status`) values (9,'1','5','Mouse','3','Logitech','Android_logo_stacked__RGB_.jpg','PAYED'),(10,'2','6','hp ','2','6 gb ram 1 tb lab','No data-cuate.png','ASSIGNED'),(11,'1','4','jj','5','jhfg jgv','_06077c5e-49a6-4a46-ae46-991931c95bf6.jpg','PAYED'),(12,'4','8','samsung','2','jcabnkj','_74b64ac4-4ce4-40e5-8ec4-ce011857cf71.jpg','PAYED');

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `l_id` int(20) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`l_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`l_id`,`u_id`,`email`,`password`,`type`,`status`) values (0,'0','admin@gmail.com','admin','ADMIN','1'),(3,'4','aji@gmail.com','12345678','USER','1'),(4,'1','prakash@gmail.com','12345678','AGENT','0'),(5,'5','vishnu12@gmail.com','123456','USER','1'),(6,'2','prashob@gmail.com','12345678','AGENT','1'),(7,'3','rugmini@gmail.com','123','AGENT','1'),(8,'6','athul@gmail.com','123','USER','1'),(9,'4','asw@mail.com','12345','AGENT','1'),(10,'7','ak@mail.com','12345','USER','1'),(11,'5','ch@mail.com','12345','AGENT','1'),(12,'8','ar@mail.com','Ar@12345','USER','1'),(13,'6','je@mail.com','Je@12345','AGENT','1');

/*Table structure for table `request` */

DROP TABLE IF EXISTS `request`;

CREATE TABLE `request` (
  `rqst_id` int(20) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(100) DEFAULT NULL,
  `ag_id` varchar(100) DEFAULT NULL,
  `item_id` varchar(100) DEFAULT NULL,
  `cat_id` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'PENDING',
  `date` varchar(100) DEFAULT '00-00-0000',
  PRIMARY KEY (`rqst_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `request` */

insert  into `request`(`rqst_id`,`u_id`,`ag_id`,`item_id`,`cat_id`,`status`,`date`) values (5,'5','2','9','1','PAYED','06-12-2021'),(6,'4','2','11','1','PAYED','14-06-2023'),(7,'8','6','12','4','PAYED','15-06-2023'),(8,'6','2','10','2','ASSIGNED','2023-06-15 17:09:01');

/*Table structure for table `user_reg` */

DROP TABLE IF EXISTS `user_reg`;

CREATE TABLE `user_reg` (
  `u_id` int(20) NOT NULL AUTO_INCREMENT,
  `u_name` varchar(100) NOT NULL,
  `u_age` varchar(100) NOT NULL,
  `u_phone` varchar(100) NOT NULL,
  `u_address` varchar(200) NOT NULL,
  `u_email` varchar(100) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `user_reg` */

insert  into `user_reg`(`u_id`,`u_name`,`u_age`,`u_phone`,`u_address`,`u_email`) values (4,'AjiN Aji','28','9947394614','Kaloor, Ernakulam','ajinaji@gmail.com'),(5,'Vishnu B Kumar','22','9879087062','Kaloor, Ernakulam, 678768','vishnu12@gmail.com'),(6,'athul s','23','9876543217','mathrubhoomi junction','athul@gmail.com'),(7,'AK','25','9898989898','AK\r\nAdrs','ak@mail.com'),(8,'Arun','25','9696969696','Ar\r\nAdrs','ar@mail.com');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
